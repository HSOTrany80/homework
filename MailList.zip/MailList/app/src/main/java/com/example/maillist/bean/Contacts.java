package com.example.maillist.bean;


/**
 * 联系人对象
 * 一些联系人对象信息的相关操作
 */
public class Contacts {

    private int id;
    private String name;//姓名
    private String phoneNumber;//电话号码


    public Contacts(String name, String phoneNumber, int call_icon, int more_icon) {
        this.name = name;
        setPhoneNumber(phoneNumber);
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
