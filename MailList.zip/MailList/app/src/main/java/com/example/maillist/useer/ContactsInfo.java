package com.example.maillist.useer;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.maillist.R;
import com.example.maillist.bean.Contacts;
import com.example.maillist.until.MySQLite;

/**
 * 显示联系人详细信息
 * 可以跳转到编辑联系人活动
 * 可以删除联系人
 */
public class ContactsInfo extends AppCompatActivity implements View.OnClickListener {

    TextView mName;
    TextView mPhoneNumber;
    Button back;
    Button update;
    TextView del;

    //临时存储当前对象的数据信息
    int id;
    String name;
    String phoneNumber;

    MySQLite nMySQLite = MySQLite.getMySQLite(this);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contacts_info);

        //初始化并设置点击事件
        initView();//初始化控件
        initText(id);//初始化显示文本
        setClickButtons();//设置按键点击监听器
    }


    @Override
    protected void onRestart() {
        super.onRestart();
        initText(id);
    }

    //根据id获取数据库中的数据，并且完成当前联系人信息的初始化
    private void initText(int id) {
        MySQLite db = MySQLite.getMySQLite(this);
        Contacts contacts = db.query(id);
        name = contacts.getName();
        phoneNumber = contacts.getPhoneNumber();
        if (name != null && phoneNumber != null) {
            mName.setText(name);
            mPhoneNumber.setText(phoneNumber);
        } else {//如果此id在数据库中没有获取到数据，给出提示
            Toast.makeText(this, "Info:系统出错，请稍后再试！", Toast.LENGTH_SHORT).show();
        }
    }

    private void setClickButtons() {
        back.setOnClickListener(this);
        update.setOnClickListener(this);
        del.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.back_info_button:
                finish();
                break;
            case R.id.update_info_button:
                Intent intent = new Intent(ContactsInfo.this, ContactsUpdate.class);
                intent.putExtra("id", id);
                startActivity(intent);
                break;
            case R.id.delete_info_text:
                dialog();//删除提示
                break;
        }

    }

    //删除提示消息框
    private void dialog() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("提示：");//提示框
        dialog.setMessage("删除联系人将无法恢复，是否继续？");//提示框消息内容
        dialog.setCancelable(false);//是否可以使用back(返回退出对话框)
        dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {//设置确定点击事件
            @Override
            public void onClick(DialogInterface dialog, int which) {
                nMySQLite.delete(id);//数据库中删除
                finish();
            }
        });
        dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(ContactsInfo.this, "取消删除!", Toast.LENGTH_SHORT).show();
            }
        });
        dialog.show();//将提示消息框显示

    }

    private void initView() {
        //获取上一个活动传递的数据
        Intent intent = getIntent();
        id = intent.getIntExtra("id", -1);
        mName = (TextView) findViewById(R.id.name_info_text);
        mPhoneNumber = (TextView) findViewById(R.id.phone_number_info_text);
        back = (Button) findViewById(R.id.back_info_button);
        update = (Button) findViewById(R.id.update_info_button);
        del = (TextView) findViewById(R.id.delete_info_text);
    }


}
