package com.example.maillist.until;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.maillist.bean.Contacts;

import java.util.ArrayList;
import java.util.List;

public class MySQLite extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "data.db";
    private static final String TAG = "MySQLite";
    private static MySQLite nMySQLite;
    SQLiteDatabase db;

    public static final String CREATE_CONTACTS_LIST = "create table ContactsList(" +
            "id integer primary key autoincrement," +
            "name text," +
            "phoneNumber text)";

    private MySQLite(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    //确保只有一个数据库操作对象
    public static MySQLite getMySQLite(Context context) {
        if (nMySQLite == null) {
            nMySQLite = new MySQLite(context, DATABASE_NAME, null, 1);
        }
        return nMySQLite;
    }


    //数据库表的创建
    @Override
    public void onCreate(SQLiteDatabase db) {
        //创建一个联系人表
        db.execSQL(CREATE_CONTACTS_LIST);

    }

    //数据库版本升级
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table ContactsList");
        onCreate(db);
    }

    //添加一条数据到数据库
    public void add(Contacts contacts) {

        db = getWritableDatabase();
        db.execSQL("insert into ContactsList(name,phoneNumber) values(?,?)", new String[]{contacts.getName(), contacts.getPhoneNumber()});
        db.close();
//        ContactsList.addContacts(contacts);
        query();
    }

    //根据id删除一条数据
    public void delete(int id) {
        db = getWritableDatabase();
        String s = "" + id;
        db.execSQL("delete from ContactsList where id = ?", new String[]{s});
        db.close();
    }

    //查询全部数据
    public List<Contacts> query() {
        db = getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from ContactsList", null);
        ArrayList<Contacts> list = new ArrayList<>();
        //将联系人信息找到并添加到联系人列表中
        Contacts contacts;
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id"));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
                @SuppressLint("Range") String phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber"));
                contacts = new Contacts(name, phoneNumber, 0, 0);
                contacts.setId(id);//设置id
                list.add(contacts);
            } while (cursor.moveToNext());
        }
        db.close();
        return list;
    }


    //根据id查询一条数据
    public Contacts query(int id) {
        db = getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from ContactsList where id = ?", new String[]{"" + id});
        Contacts contacts = null;
        if (cursor.moveToFirst()) {
            @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
            @SuppressLint("Range") String phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber"));
            contacts = new Contacts(name, phoneNumber, 0, 0);
        }
        db.close();
        return contacts;
    }

    //修改数据库的数据，传入一个需要修改的数据对象
    public void update(Contacts contacts) {
        db = getWritableDatabase();
        db.execSQL("update ContactsList set name = ?,phoneNumber = ? where id = ?", new String[]{contacts.getName(), contacts.getPhoneNumber(), contacts.getId() + ""});
        db.close();
    }
    public Contacts findContactByName(String name) {
        db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM ContactsList WHERE name = ?", new String[]{name});
        Contacts contacts = null;
        if (cursor.moveToFirst()) {
            @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id"));
            @SuppressLint("Range") String phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber"));
            contacts = new Contacts(name, phoneNumber, 0, 0);
            contacts.setId(id);
        }
        cursor.close();
        db.close();
        return contacts;
    }

}
