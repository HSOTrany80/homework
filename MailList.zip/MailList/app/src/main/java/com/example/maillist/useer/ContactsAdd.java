package com.example.maillist.useer;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.maillist.R;
import com.example.maillist.bean.Contacts;
import com.example.maillist.until.MySQLite;

/**
 * 添加联系人的Activity界面，管理界面控件并处理添加联系人的逻辑
 */
public class ContactsAdd extends AppCompatActivity implements View.OnClickListener {

    //添加联系人活动的一些控件
    EditText name;
    EditText phoneNumber;
    Button confirm;
    Button back;

    MySQLite mMySQLite = MySQLite.getMySQLite(this);


    int flag = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_layout);
        initView();
        setClickButton();

    }

    //执行活动销毁的业务逻辑
    @Override
    protected void onDestroy() {
        super.onDestroy();

        //根据状态执行对应逻辑
        switch (flag) {
            case 0://back
                clearEditText();
                break;
            case 1://save
                break;
            case 2://yes
                clearEditText();
                break;
        }

    }

    //初始化控件对象
    private void initView() {
        name = (EditText) findViewById(R.id.name_add_edit);
        phoneNumber = (EditText) findViewById(R.id.phone_number_add_edit);
        confirm = (Button) findViewById(R.id.add_back_button);
        back = (Button) findViewById(R.id.add_yes_button);
    }

    //为按键设置监听器
    private void setClickButton() {
        confirm.setOnClickListener(this);
        back.setOnClickListener(this);
    }

    //设置按键点击事件
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.add_back_button:
                flag = 0;
                finish();
                break;
            case R.id.add_yes_button://将这个页面的数据存放到联系人数据库中
                flag = 2;
                createContacts();
                break;
        }

    }

    private void createContacts() {
        //根据用户输入创建一个联系人对象
        Contacts contacts = new Contacts(name.getText().toString(), phoneNumber.getText().toString(), 0, 0);
        if (contacts.getPhoneNumber() != null && !contacts.getPhoneNumber().equals("")) {//判断是否输入号码
            //将联系人对象添加到数据库
            mMySQLite.add(contacts);
            Toast.makeText(this, "添加成功!", Toast.LENGTH_SHORT).show();

            finish();
        } else {
            Toast.makeText(this, "数据有误!", Toast.LENGTH_SHORT).show();
        }
    }


    private void clearEditText() {
        //这个是为了保存后不在将输入框的数据存放到文件,避免添加成功后，下次恢复已经添加的数据到添加输入框中
        name.setText("");
        phoneNumber.setText("");
    }
}

