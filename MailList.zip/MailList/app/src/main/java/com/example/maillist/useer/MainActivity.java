package com.example.maillist.useer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
//import android.support.v7.widget.SearchView;
import android.view.View;
import android.widget.Button;

import com.example.maillist.R;
import com.example.maillist.adaptr.MyAdapter;
import com.example.maillist.bean.Contacts;
import com.example.maillist.until.MySQLite;

import java.util.Comparator;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    List<Contacts> list;//数据库中读取的联系人数据
    MySQLite mMySQLite = MySQLite.getMySQLite(this);//操作数据库的对象

    //活动一开始旧执行的代码
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialization();
        Button addBtn = (Button) findViewById(R.id.add_btn);
        Button findBtn = (Button) findViewById(R.id.search_view);
        findBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ContactsFind.class);
                startActivity(intent);
            }
        });
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ContactsAdd.class);
                startActivity(intent);
            }
        });

    }

    //活动创建需要初始化的数据
    private void initialization() {
        initContacts();
        initRecyclerView();
    }

    //活动重新开始，重新执行初始化数据，将数据库中修改的数据直接同步一遍
    @Override
    protected void onRestart() {
        super.onRestart();
        initialization();
    }


    //软件运行时，修改数据库后刷新控件
    private void initRecyclerView() {
        //获取RecycleView对象
        RecyclerView recycle = (RecyclerView) findViewById(R.id.recycle_view);
        //创建自定义适配器
        MyAdapter adapter = new MyAdapter(list, this);
        //用于指定布局方式
        RecyclerView.LayoutManager manager = new LinearLayoutManager(this);
        recycle.setLayoutManager(manager);
        recycle.setAdapter(adapter);
    }


    //打开软件获取数据库数据，初始化联系人列表
    private void initContacts() {
        //从数据库中查询联系人信息
        list = mMySQLite.query();
        //排序显示
        list.sort(new Comparator<Contacts>() {
            @Override
            public int compare(Contacts o1, Contacts o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });
    }


}
