package com.example.maillist.useer;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.maillist.R;
import com.example.maillist.bean.Contacts;
import com.example.maillist.until.MySQLite;

/**
 * 联系人信息编辑界面
 */
public class ContactsUpdate extends AppCompatActivity implements View.OnClickListener {

    private int id;
    EditText name;
    EditText phoneNumber;
    Button save;
    Button back;

    MySQLite mMySQLite = MySQLite.getMySQLite(this);

    Contacts mContacts;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contacts_update_layout);
        initView();
        initEdit();
        setClickButton();


    }

    private void setClickButton() {
        save.setOnClickListener(this);
        back.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.save_update_button:
                saveUpdate();//保存修改的数据到数据库中
                break;
            case R.id.back_update_button:
                Toast.makeText(this, "修改取消!", Toast.LENGTH_SHORT).show();
                break;
        }
        finish();
    }

    private void saveUpdate() {
        mContacts.setId(id);
        mContacts.setName(name.getText().toString());
        mContacts.setPhoneNumber(phoneNumber.getText().toString());
        mMySQLite.update(mContacts);//修改数据库
        Toast.makeText(this, "修改成功!", Toast.LENGTH_SHORT).show();
    }


    //根据id从数据库中查询数据，对输入框将旧数据显示
    private void initEdit() {
        mContacts = mMySQLite.query(id);
        if (mContacts != null) {
            this.name.setText(mContacts.getName());
            this.phoneNumber.setText(mContacts.getPhoneNumber());
        }
    }

    private void initView() {
        id = getIntent().getIntExtra("id", -1);
        name = (EditText) findViewById(R.id.name_update_edit);
        phoneNumber = (EditText) findViewById(R.id.phone_number_update_edit);
        save = (Button) findViewById(R.id.save_update_button);
        back = (Button) findViewById(R.id.back_update_button);
    }

}
