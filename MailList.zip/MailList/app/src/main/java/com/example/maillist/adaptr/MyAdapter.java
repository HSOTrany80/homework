package com.example.maillist.adaptr;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.maillist.bean.Contacts;
import com.example.maillist.useer.ContactsInfo;
import com.example.maillist.R;

import java.util.List;

/**
 * RecyclerView自定义适配器
 * 动态加载了子项的资源
 * 编写了子项的点击逻辑
 */
public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    List<Contacts> list;
    Activity main;//传入主活动对象，用于调用startActivity跳转页面

    static class ViewHolder extends RecyclerView.ViewHolder {
        View contacts;//记录父类控件id
        int id;
        TextView contactsName;
        TextView contactsPhoneNumber;
        TextView contactsCall;
        TextView contactsMore;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            //初始化控件
            contacts = itemView;//记录这个父类控件id
            contactsName = itemView.findViewById(R.id.contacts_name);
            contactsPhoneNumber = itemView.findViewById(R.id.contacts_phone_number);
            contactsCall = itemView.findViewById(R.id.call_icon);
            contactsMore = itemView.findViewById(R.id.more_icon);
        }
    }

    //创建一个可以传入数据的构造器
    public MyAdapter(List<Contacts> list, Activity activity) {
        this.list = list;
        main = activity;//构造器初始化传入的主活动对象
    }

    //onCreateViewHolder方法用于ViewHolder滑动到屏幕是动态加载加载布局，并且将加载的布局返回后存储
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contacts_item, parent, false);
        ViewHolder holder = new ViewHolder(view);

        //设置点击监听
        holder.contactsCall.setOnClickListener(new View.OnClickListener() {//拨打电话
            @Override
            public void onClick(View v) {//设置拨打电话Intent跳转
                String phoneNumber = holder.contactsPhoneNumber.getText().toString();
                Intent intent = new Intent(Intent.ACTION_DIAL);//意图：拨号行动
                intent.setData(Uri.parse("tel:" + phoneNumber));//设置对应的号码
                main.startActivity(intent);
            }
        });
        holder.contactsMore.setOnClickListener(new View.OnClickListener() {//跳转至详情页面
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(main, ContactsInfo.class);
                intent.putExtra("id", holder.id);
                intent.putExtra("name", holder.contactsName.getText().toString());
                intent.putExtra("phoneNumber", holder.contactsPhoneNumber.getText().toString());
                main.startActivity(intent);
            }
        });
        holder.contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        return holder;
    }


    //为滑动到屏幕的holder布局设置资源文件
    //传入一个holder和对应的号数，为其设置资源文件
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Contacts contacts = list.get(position);
        holder.id = contacts.getId();//设置每个子项的id
        holder.contactsName.setText(contacts.getName());
        holder.contactsPhoneNumber.setText(contacts.getPhoneNumber());
        holder.contactsCall.setText("📞");
        holder.contactsMore.setText("···");
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


}
