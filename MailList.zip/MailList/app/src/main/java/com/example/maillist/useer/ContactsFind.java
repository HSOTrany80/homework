package com.example.maillist.useer;

import com.example.maillist.bean.Contacts;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
//import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import com.example.maillist.R;
import com.example.maillist.until.MySQLite;

import scut.carson_ho.searchview.ICallBack;
import scut.carson_ho.searchview.SearchListView;
import scut.carson_ho.searchview.SearchView;
import scut.carson_ho.searchview.bCallBack;

public class ContactsFind extends Activity  {

    int id;
    String name;
    String mPhoneNumber;
    MySQLite sMySQLite = MySQLite.getMySQLite(this);

    public void initView() {
        id = getIntent().getIntExtra("id", 0);
        name = getIntent().getStringExtra("name");
        mPhoneNumber = getIntent().getStringExtra("phoneNumber");
    }

    // 1. 初始化搜索框变量
    private SearchView searchView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 2. 绑定视图
        setContentView(R.layout.activity_contacts_find);

        // 3. 绑定组件
        searchView = (SearchView) findViewById(R.id.search_view);


        // 4. 设置点击键盘上的搜索按键后的操作（通过回调接口）
        // 参数 = 搜索框输入的内容
        searchView.setOnClickSearch(new ICallBack() {
            @Override
            public void SearchAciton(String string) {
                // 5.2 通过输入框的内容查询数据库
                Contacts contacts = sMySQLite.findContactByName(string); // 修改这里
                // 5.3 判断查询结果
                if (contacts == null) {
                    Toast.makeText(ContactsFind.this, "没有找到该联系人", Toast.LENGTH_SHORT).show();
                } else {
                    name = contacts.getName();
                    sMySQLite.query(id);
                    // 5.4 跳转到联系人详细信息界面
                    Intent intent = new Intent(ContactsFind.this, ContactsInfo.class);
                    intent.putExtra("id", contacts.getId());
                    startActivity(intent);
                }
            }
        });


        // 5. 设置点击返回按键后的操作（通过回调接口）
        searchView.setOnClickBack(new bCallBack() {
            @Override
            public void BackAciton() {
                finish();
            }
        });
    }
}
